#include <iostream>
#include<vector>
using namespace std;
int main() {
  vector<int>arr;
  cout<<"size of arr is"<<" "<<arr.size()<<endl;
  cout<<"Capacity of arr is"<<" "<<arr.capacity()<<endl;

  arr.push_back(10);
  arr.push_back(23);
  arr.push_back(30);
  for(int i=0; i<arr.size(); i++){
    cout<<arr[i]<<" ";
  }
  cout<<endl;
  //delete or remove
  arr.pop_back();
  for(int i=0; i<arr.size(); i++){
    cout<<arr[i]<<" ";
  }
  cout<<endl;

  int n;
   cout<<"Enter the value of n"<<endl;
  cin>>n;
 
  vector<int>brr(n,-10);
  cout<<"size of arr is"<<" "<<brr.size()<<endl;
  cout<<"Capacity of arr is"<<" "<<brr.capacity()<<endl;
  
  for(int i=0; i<brr.size(); i++){
    cout<<brr[i]<<" ";
  }
  cout<<endl;
  cout<<"printing crr"<<endl;
  vector<int>crr{20,30,50,40};
  for(int i=0; i<crr.size(); i++){
    cout<<crr[i]<<" ";
  }
  cout<<endl;

  vector<int>drr;
  cout<<"size of array is"<<" "<<drr.empty()<<endl;

  cout<<"size of crr array is"<<" "<<crr.empty()<<endl;
  return 0;
}