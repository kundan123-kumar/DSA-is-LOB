#include <iostream>
#include<vector>
using namespace std;

int main() {
  vector<int> arr{3,56,78,9,10,20,30};
  // int sizea=7;
  vector<int> brr{4,7,13,10,30,33};
  // int sizeb=6;
  vector<int>ans;

  for(int i=0; i<arr.size(); i++){
    int element = arr[i];

  for(int j=0; j<brr.size(); j++){
    if(element==brr[j]){
      ans.push_back(element);
    }
  }
  
}
for(auto value: ans){
  cout<<value<<" ";
}
  return 0;
}