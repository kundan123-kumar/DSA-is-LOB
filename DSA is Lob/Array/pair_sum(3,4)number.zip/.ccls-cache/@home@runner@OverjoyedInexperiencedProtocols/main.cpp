#include <iostream>
#include<vector>
using namespace std;
//for triplate sum
// int main() {
//     vector<int> arr{36,56,89,12,34};
//   int sum=135;
//   for(int i=0; i<arr.size(); i++){
//     int element1 = arr[i];
    
//     for(int j=i+1; j<arr.size(); j++){
//       int element2 = arr[j];
      
//       for(int k=j+1; k<arr.size(); k++){
//         int element3 = arr[k];
        
//         if(element1+element2+element3==sum){
//           cout<<element1<<","<<element2<<","<<element3<<endl;
//         }
//       }
//     }
//   }
// }

//for four number
int main() {
    vector<int> arr{36,56,89,12,10,20,34};
  int sum=76;
  for(int i=0; i<arr.size(); i++){
    int element1 = arr[i];

    for(int j=i+1; j<arr.size(); j++){
      int element2 = arr[j];

      for(int k=j+1; k<arr.size(); k++){
        int element3 = arr[k];
        
        for(int s=k+1; s<arr.size(); s++){
          int element4 = arr[s];
          
          if(element1+element2+element3+element4==sum){
            cout<<element1<<","<<element2<<","<<element3<<","<<element4<<endl;
          }
        }
      }
    }
  }
}
