#include <iostream>
#include<vector>
using namespace std;

// int main() {
//   //pair sum
//    vector<int> arr{1,2,3,45,6,7};

// // pair all pairs
//   //outer loop will traverse for each element
//   for(int i=0; i<arr.size(); i++){
//     cout<<"We are at element:"<<arr[i]<<endl;
//     int element= arr[i];
//     // for every element tverse on all other elements
//     for(int j=i+1; j<arr.size(); j++){
//       cout<<"pair:"<<element<<"with"<<arr[j]<<endl;
//       // cout<<"("<<element<<","<<arr[j]<<")"<<endl;
//     }
    
//   }
// }

// sum number 
int main(){
  vector<int> arr{10,20,30,40,50,60};
  int sum=90;
  for(int i=0; i<arr.size(); i++){
    int element=arr[i];
    for(int j=i+1; j<arr.size(); j++){
      if(element+arr[j]==sum){
        cout<<"pair found"<<element<<","<<arr[j]<<endl;
      }
    }
  }
}