#include <iostream>
// #include <vector>
using namespace std;

int main() {
  // int arr[3][3];
  // int brr[3][3]={
  // {1,2,3},
  // {4,5,6},
  // {7,8,9}};
  // for(int i=0; i<3; i++){
  //   for(int j=0; j<3; j++){
  //     cout << brr[i][j]<<" ";
  //     }
  //   cout<<endl;
  // }
  // cout<<"Printing row wise"<<endl;
  // for(int i=0; i<3; i++){
  //   for(int j=0; j<3; j++){
  //     cout << brr[j][i]<<" ";
  //     }
  //   cout<<endl;
  // }

  int arr[4][3]; 
  int row=4;
  int col=3;
  for(int i=0; i<row; i++){
    for(int j=0; j<col; j++){
      // cout<<"Enter the input";
      cin>> arr[i][j];
    }

  }

  cout<<"Enter the elements"<<endl;
  for(int i=0; i<row; i++){
    for(int j=0; j<col; j++){
      cout<<arr[i][j]<<" ";
    }
  }


  return 0;
}