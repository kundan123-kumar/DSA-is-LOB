#include <iostream>
#include<vector>
using namespace std;

// int findUnique(vector<int>arr){
//   int ans=0;
//   for(int i=0; i<arr.size(); i++){
//     ans=ans^arr[i];
//   }
//   return ans;
// }
// int main() {
//   int n;
//   cout<<" Enter the size of the array"<<endl;
//   cin>>n;
  
//   vector<int>arr(n);
//   cout<<"Enter the element"<<endl;
//   for(int i=0; i<arr.size(); i++){
//     cin>>arr[i];
//   }
//   int uniquElement = findUnique(arr);
//   cout<<" Unique element is"<<uniquElement<<endl;
// }

//unione of two number
int main(){
  int arr[]={2,3,45,6,8};
  int sizea=5;
  int brr[]={4,9,13,34};
  int sizeb=4;

  vector<int>ans;
  //push all element of arr
  for(int i=0; i<sizea; i++){
    ans.push_back(arr[i]);
  }
  //push all element of brr
  for(int i=0; i<sizeb; i++){
    ans.push_back(brr[i]);
  }
  //print ans
  cout<<"print the all array"<<endl;
  for(int i=0; i<ans.size(); i++){
    cout<<ans[i]<<" "<<endl;
  }
  
}